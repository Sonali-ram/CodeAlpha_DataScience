import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
df = pd.read_csv("Iris.csv")

'''
print(df.head())
print("Shape",df.shape)
print(df.info())
print(df.describe)
'''

print("Missing values in each Columns")
print(df.isnull().sum())